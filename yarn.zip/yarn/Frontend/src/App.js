import { Route, Routes,Navigate } from "react-router-dom";
import Signup from "./components/Signup.js";
import Home from "./components/Home.js";
import IndexPage from "./components/IndexPage";
import CreatePost from "./components/CreatePost.js";
import {fetchPosts} from "./components/Slices/postSlice.js";
import { useDispatch } from 'react-redux';
import {useEffect} from 'react';
import SavePost from "./components/SavedPost.js";
import "./style.scss";
import App1 from "./App1.js";
import Nav from "./components/Nav.js";


function App() {
let dispatch = useDispatch();
useEffect(()=>{
 <Nav/>
dispatch(fetchPosts());

},[]);


  return (
    <div>
    <Routes>
      <Route path="/" element={<IndexPage/>}></Route>
      <Route path="/home" element={<Home/>}></Route>
      <Route path="/createPost" element={<CreatePost/>}></Route>
      <Route path="/savePost" element={<SavePost/>}></Route>
      <Route path="/chat" element={<App1/>}></Route>

    
    </Routes>
   
    </div>
  );
}

export default App;
