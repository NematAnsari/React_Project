import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
import { getFirestore } from "firebase/firestore";


const firebaseConfig = {
  apiKey: "AIzaSyCuLpwZW4bBOphphBvL8gdAGYRiwEXM_1U",
  authDomain: "homebuilder-6f2cf.firebaseapp.com",
  projectId: "homebuilder-6f2cf",
  storageBucket: "homebuilder-6f2cf.appspot.com",
  messagingSenderId: "246219313555",
  appId: "1:246219313555:web:19804c6f1d214ab1ed9866"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth();
export const storage = getStorage();
export const db = getFirestore()
