
import Sidebar from '../components/Sidebar'
import Chat from '../components/Chat'
import { Link } from 'react-router-dom';
import SideButton from '../components/SideButton';
import icon from '../components/icon.jpeg';
import React, { useContext } from 'react'
import { AuthContext } from '../context/AuthContext';
import { current } from '@reduxjs/toolkit';
import { borderRadius } from '@mui/system';

const Home = () => {
  const {currentUser}= useContext(AuthContext);
  return (
    <div >
    <aside className="sidebarCode" style={{width:'20%'}}>

                  <div><span>{currentUser.displayName}</span></div>

       <nav className="navBarCode" >

      <div className="profilepic">
                      <div className="profile_img">
                        <div className="image">
                        <img src={currentUser.photoURL} alt="" />
                        </div>
                      </div>
      </div>
 
    <h2 className='text-white text-center mt-5 mb-5'> <b>{currentUser.displayName}</b></h2>
        
        <b><ul style={{fontSize:'1vw'}}>
          <li><Link  to="/createPost">Create Post </Link></li>
          <li><Link  to="/savePost">Saved Post</Link></li>
          <li><Link  to="/chat">Chat</Link></li>
          <li><Link  to="/">Logout</Link></li>
        </ul>
        </b>

      </nav>
    </aside>
<div className='home'>
      <div className="container" style={{marginLeft:'25%'}}>
        
        <Sidebar/>
        <Chat/>
      </div>
    </div>
      </div>
  )
}

export default Home