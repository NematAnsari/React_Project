import React, { useContext } from 'react'
import {signOut} from "firebase/auth";
import { auth } from '../firebase';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';


const Navbar = () => {
  const navigate = useNavigate();
    const logOut=()=>{
     let a=signOut(auth);
     console.log(a);
    //  navigate("/");
    }

  const {currentUser}= useContext(AuthContext);
  console.log(currentUser.displayName);
  return (
    <div className='navbar' >
      <span className="logo">People's Chat</span>
      <div className='user'>
        <img src={currentUser.photoURL} alt="" />
        <span>{currentUser.displayName}</span>
        <button onClick={logOut}>logout</button>
      </div>
      
    </div>
  )
}

export default Navbar
