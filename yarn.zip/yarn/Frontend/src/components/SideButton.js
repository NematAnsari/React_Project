function SideButton(){
    return<>
    <div className="row" style={{}}>
        <div className="col md-4"></div>
        <div className="col md-4"></div>
        <div className="col md-4"></div>
        <div className="col md-4">

        <button type="button" className="btn btn-primary btn-lg btn-block">Block level button</button>
        </div>

    </div>
    </>
}
export default SideButton;