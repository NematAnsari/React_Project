import axios from "axios";
import React, { useState } from 'react'
import { useDispatch } from "react-redux";
import { Link, useNavigate } from 'react-router-dom';
import { fetchPosts } from "./Slices/postSlice";
import { setCustomer } from "./Slices/userSlice";
import Add from "../image/logo.png";
import {createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth ,storage,db} from "../firebase";
import {  ref,uploadBytesResumable , getDownloadURL } from "firebase/storage";
import { doc, setDoc } from "firebase/firestore";
import { signInWithEmailAndPassword } from "firebase/auth";

const Header = () => {
  const navigate = useNavigate();
  const [signUpEmail,setSignUpEmail] = useState("");
  const [signUpPassword,setSignUpPassword] = useState("");
  const [loginEmail,setLoginEmail] = useState("");
  const [loginPassword,setLoginPassword] = useState("");
  const [user,setUser] = useState("");
  const [name,setName] = useState("");
  const [avtar,setAvtar] = useState("");
  const [loading, setLoading] = useState(false);
  const [err1, setErr1] = useState(false);
  let dispatch = useDispatch();
   const signup = (e) =>{
    e.preventDefault();
    let obj = {
      name:name,
      email:signUpEmail,
      password:signUpPassword,
      user:user
    }
   
  let response = axios.post("http://localhost:3000/user/signup",obj).then(res=>alert("Signup  Successfully"));
  dispatch(setCustomer(obj));

//  console.log(response.data.user);
   }
   const login = async () =>{

    let response = await axios.post("http://localhost:3000/user/login",{email:loginEmail,password:loginPassword});
         if(response.request.status==200)
         {
          dispatch(setCustomer(response.data.user));
          // alert(response.data.message);
          dispatch(fetchPosts());
        console.log(response.data.user);
          firbaseLogin(response.data.user);
          
        }
        else 
        alert(response.data.message);

   }



   const firbaseSignUp = async (e)=>{
    console.log(e);
    setLoading(true);
    e.preventDefault();
   alert("handlesubmmit ccall");
    const displayName = name;
    const email = signUpEmail;
    const password = signUpPassword;
    const file = e.target[0].files[0];
    alert(file);
    
    try {
    const res = await createUserWithEmailAndPassword(auth, email, password)
    
    const storageRef = ref(storage,displayName);
    
    const uploadTask = uploadBytesResumable(storageRef, file);
    
    uploadTask.on(
    
      (error) => {
        setErr1(true);
      }, 
      () => {
        getDownloadURL(uploadTask.snapshot.ref).then(async (downloadURL) => {
          await updateProfile(res.user,{
            displayName,
            photoURL:downloadURL,
          });
          await setDoc(doc(db,"users",res.user.uid),{
            uid:res.user.uid,
           displayName,
           email,
           photoURL: downloadURL,
          });
    
          await  setDoc(doc (db,"userChats", res.user.uid),{});
        signup(e);
   
        });
      }
    );
 }catch(err){
    setErr1(true);
    }};

    const firbaseLogin = async (user)=>{
 
      const email = signUpEmail;
      const password = signUpPassword;
      
      try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate("/home",user);
      }catch(err){
      setErr1(true);
      }};
    
  return (
    <div>
      <header id="header">
  <div className="container-fluid">
    <div id="logo" className="pull-left">
      <h1><a href="#intro" className="scrollto">Home Builder</a></h1>
      {/* Uncomment below if you prefer to use an image logo */}
      {/* <a href="#intro"><img src="img/logo.png" alt="" title="" /></a>*/}
    </div>
    <nav id="nav-menu-container">
      <ul className="nav-menu">
        <li className="menu-active"><a href="#intro">Home</a></li>
        <li><a href="#portfolio">PortFolio</a></li>
        {/* <li><a href="#team">SignUp</a></li> */}
        <li><a href="#about">About Us</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><Link><button type="button" className=" h1 btn btn-outline-success text-white text-bold" data-toggle="modal" data-target="#exampleModalCenter">
                Login
              </button>
    <div className="modal fade" id="exampleModalCenter" data-backdrop="false" tabIndex={-1} role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <button type="button" className="close d-flex align-items-center justify-content-center" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true" className="ion-ios-close" />
            </button>
          </div>
          <div className="modal-body p-4 py-5 p-md-5">
            <h3 className="text-center mb-3">Login Account</h3>
            <ul className="ftco-footer-social p-0 text-center">
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Twitter"><span className="ion-logo-twitter" /></a></li>
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Facebook"><span className="ion-logo-facebook" /></a></li>
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Instagram"><span className="ion-logo-instagram" /></a></li>
            </ul>
            <form action="#" className="signup-form">
              <div className="form-group mb-2">
                <label htmlFor="email">Email Address</label>
                <input type="text" className="form-control"  onChange={(event)=>setLoginEmail(event.target.value)}/>
              </div>
              <div className="form-group mb-2">
                <label htmlFor="password">Password</label>
                <input type="password" className="form-control"  onChange={(event)=>setLoginPassword(event.target.value)}/>
              </div>
              <div className="form-group mb-2">
                <button  onClick={login}  className="form-control btn btn-primary rounded submit px-3">Sign In</button>
              </div>
              <div className="form-group d-md-flex">
                <div className="w-100 text-center">
                  <a href="#" className="forgot">I'm already a member</a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div></Link></li>
{/* Login  Modal  */}



    {/* Sign UP Modal  */}
    <li><a href="#"><button type="button" className=" h1 btn btn-outline-success text-white text-bold" data-toggle="modal" data-target="#exampleModalCenter1">
                SignUp
              </button>
    <div className="modal fade" id="exampleModalCenter1" data-backdrop="false" tabIndex={-1} role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <button type="button" className="close d-flex align-items-center justify-content-center" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true" className="ion-ios-close" />
            </button>
          </div>
          <div className="modal-body p-4 py-5 p-md-5">
            <h3 className="text-center mb-3">Create Your Account</h3>
            <ul className="ftco-footer-social p-0 text-center">
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Twitter"><span className="ion-logo-twitter" /></a></li>
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Facebook"><span className="ion-logo-facebook" /></a></li>
              <li className="ftco-animate"><a href="#" data-toggle="tooltip" data-placement="top" title="Instagram"><span className="ion-logo-instagram" /></a></li>
            </ul>

            <form onSubmit={firbaseSignUp} className="signup-form">
            <input type='file' required style={{ display: "none" }} id='file'/>
              <label htmlFor="file">
              <span>Add Avatar profile</span>
            <img src={Add} alt="" />
       
            </label>
              <div className="form-group mb-2">
                <label htmlFor="name">Full Name</label>
                <input type="text" className="form-control"  onChange={(event)=>setName(event.target.value)}/>
              </div>
              <div className="form-group mb-2" >
                <label htmlFor="email">Email Address</label>
                <input type="text" className="form-control"  onChange={(event)=>setSignUpEmail(event.target.value)} />
              </div>
              <div className="form-group mb-2">
                <label htmlFor="password">Password</label>
                <input type="password" className="form-control" placeholder="Password" onChange={(event)=>setSignUpPassword(event.target.value)} />
              </div>
           
              <select style={{width:'100%' ,height:'20%'}} className='form-control mt-2 mb-3' onChange={(event)=>{setUser(event.target.value)}}>
              
                <option value="#">Select User </option>
                <option value="Customer">Customer </option>
                <option value="Builder">Builder</option>
              </select>

              <div className="form-group mb-2  mt-5">
              <button className="form-control btn btn-primary rounded submit px-3">Sign up</button>
          
             </div>
              <div className="form-group d-md-flex">
                <div className="w-100 text-center">
                  <a href="#" className="forgot">I'm already a member</a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div></a></li>
      </ul>
    </nav>
  </div>
</header>

    </div>
  )
}

export default Header



