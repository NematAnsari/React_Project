import React, { useContext } from 'react'
import icon from './icon.jpeg'
import { Link } from 'react-router-dom';
import "./css/sidebar.scss";
import Post from './Post';
import SideButton from './SideButton';
import { AuthContext } from '../context/AuthContext';
const Nav = () => {
  const {currentUser}= useContext(AuthContext);
  return (
    <div >
  <aside className="sidebarCode" style={{width:'20%'}}>

<div><span>{currentUser.displayName}</span></div>

<nav className="navBarCode" >

<div className="profilepic">
    <div className="profile_img">
      <div className="image">
      <img src={currentUser.photoURL} alt="" />
      </div>
    </div>
</div>

<h2 className='text-white text-center mt-5 mb-5'> <b>{currentUser.displayName}</b></h2>

<b><ul style={{fontSize:'2vh'}}>
<li><Link  to="/createPost">Create Post </Link></li>
<li><Link  to="/savePost">Saved Post</Link></li>
<li><Link  to="/chat">Chat</Link></li>
<li><Link  to="/">Logout</Link></li>
</ul>
</b>

</nav>
</aside>
  <SideButton/>
  
<Post></Post>
    </div>
  )
}

export default Nav
