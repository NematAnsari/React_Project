import { doc, updateDoc, deleteField } from "firebase/firestore";

const cityRef = doc(db, 'messages', 'hi');

// Remove the 'capital' field from the document
await updateDoc(cityRef, {
    capital: deleteField()
});