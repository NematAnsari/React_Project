import React from 'react';


import Header from './Header';
import Nav from './Nav';


const Home = () => {

  return (
    <div>
        <Nav></Nav>
      
       </div>
  )
}

export default Home;





// import React from 'react'
// import Nav from "./Nav.js";
// import Header from "./Header.js";
// import Section from "./Section.js";
// import AboutUs from "./AboutUs.js";
// import Services from "./Services.js";
// import Facts from "./Facts.js";
// import PortFolio from "./PortFolio.js";
// import Testimonials from "./Testimonials.js";
// import Team from "./Team.js";
// import Contact from "./Contact.js";
// import Footer from "./Footer.js";

// const Home = () => {
//   return (
//     <div>
//        <Header></Header>
//     <Section></Section>
//     <AboutUs></AboutUs>
//     <Services></Services>
//     <Facts></Facts>
//     <PortFolio></PortFolio>
//     <Testimonials></Testimonials>
//     <Team></Team>
//     <Contact></Contact>
//     <Footer></Footer>
//     </div>
//   )
// }

// export default Home
